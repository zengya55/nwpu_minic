#include <stdio.h>
#include <stdlib.h>

using namespace std;

enum {Num};
double token;
double token_val;
bool type;
char *line = NULL;
char *src = NULL;
void next() {
// skip white space
while (*src == ' ' || *src == '\t') {
src ++;
}
token = *src++;
if (token >= '0' && token <= '9' ) {
token_val = token - '0';
token = Num;

while (*src >= '0' && *src <= '9') {
token_val = token_val*10 + *src - '0';
src ++;
}
if(*src == '.' )
{
  type=1;
token = Num;
src ++;
while (*src >= '0' && *src <= '9') {
token_val = token_val+(*src - '0')*0.1;
src ++;
}  
}
}
return;
}
void match(double tk) {
if (token != tk) {
printf("expected token: %lf(%c), got: %lf(%c)\n", tk, tk, token, token);
exit(-1);
}
next();
}


double expr();

double factor() {
double value = 0;
if (token == '(') {
match('(');
value = expr();
match(')');
} else {
value = token_val;
match(Num);
}
return value;
}


double term_tail(double lvalue) {
if (token == '*') {
match('*');
double value = lvalue * factor();
return term_tail(value);
} else if (token == '/') {
match('/');
double value;
if(!type) {
    int a=(int)lvalue;
    int b=(int)factor();
    int c=a/b;
    value = c;
}
else value = lvalue / factor();
// printf("/ value is %lf\n", value);
return term_tail(value);
} else {
return lvalue;
}
}


double term() {
double lvalue = factor();
return term_tail(lvalue);
}


double expr_tail(double lvalue) {
if (token == '+') {
match('+');
double value = lvalue + term();
return expr_tail(value);
} else if (token == '-') {
match('-');
double value = lvalue - term();
return expr_tail(value);
} else {
return lvalue;
}
}


double expr() {
double lvalue = term();
return expr_tail(lvalue);
}

int main(int argc, char *argv[])
{
size_t linecap = 0;
ssize_t linelen;
while ((linelen = getline(&line, &linecap, stdin)) > 0) {
src = line;
next();
double value=expr();
if(type)
printf("%lf\n", value);
else
printf("%d\n", int(value));
type=0;
}
return 0;
}