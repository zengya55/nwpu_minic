#include "expr.h"

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

// expression allocate
struct expr * expr_alloc(int type, float val)
{
    struct expr *tmp_node = NULL;

    tmp_node = (struct expr*)malloc(sizeof(struct expr));
    if(NULL == tmp_node) {
        printf("memory alloc failed\n");
        return NULL;
    }

    tmp_node->type = type;
    tmp_node->val = val;

    return tmp_node;
}

// expression print
void expr_print(struct expr * obj)
{
    if(INT_TYPE == obj->type){
        printf("%d\n", (int)(obj->val));
    }
    else if(REAL_TYPE == obj->type){
        printf("%.2f\n", (obj->val));
    }
}

// expresion add
int expr_add(struct expr * src1, struct expr *src2, struct expr * result)
{
    // TODO real number add
    result->type = src1->type >= src2->type ? src1->type : src2->type;
    result->val = src1->val + src2->val;

    // Success
    return 0;
}

// expresion sub
int expr_sub(struct expr * src1, struct expr *src2, struct expr * result)
{
    // TODO real number add
    result->type = src1->type >= src2->type ? src1->type : src2->type;
    result->val = src1->val - src2->val;

    // Success
    return 0;
}

// expresion multiply
int expr_mult(struct expr * src1, struct expr *src2, struct expr * result)
{
    // TODO real number add
    result->type = src1->type >= src2->type ? src1->type : src2->type;
    result->val = src1->val * src2->val;

    // Success
    return 0;
}

// expresion divide
int expr_divid(struct expr * src1, struct expr *src2, struct expr * result)
{
    // TODO real number add
    result->type = src1->type >= src2->type ? src1->type : src2->type;
    if(INT_TYPE == result->type){
        result->val = (int)src1->val / (int)src2->val;
    }
    else{
        result->val = src1->val / src2->val;
    }

    // Success
    return 0;
}

